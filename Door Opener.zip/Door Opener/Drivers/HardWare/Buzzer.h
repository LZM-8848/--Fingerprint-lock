/*
 * Buzzer.h
 *
 *  Created on: Nov 23, 2024
 *      Author: R
 */

#ifndef HARDWARE_BUZZER_H_
#define HARDWARE_BUZZER_H_
void Buzzer_ON(void);

void Buzzer_OFF(void);


void Buzzer_Turn(void);


#endif /* HARDWARE_BUZZER_TIM_H_ */
