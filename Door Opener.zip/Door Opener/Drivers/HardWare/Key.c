/*
 * Key.c
 *
 *  Created on: Nov 23, 2024
 *      Author: R
 */
#include "main.h"


int Key_GetNum (void)
{
	int KeyNum = 0;
	if (HAL_GPIO_ReadPin(Key_GPIO_Port, Key_Pin) == GPIO_PIN_SET)
		{
			HAL_Delay(20);
			while(HAL_GPIO_ReadPin(Key_GPIO_Port, Key_Pin) == GPIO_PIN_SET);
			HAL_Delay(20);
			KeyNum = 1;
		}
	return KeyNum;
}

