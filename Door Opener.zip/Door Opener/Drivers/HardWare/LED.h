/*
 * LED.h
 *
 *  Created on: Dec 14, 2024
 *      Author: R
 */

#ifndef HARDWARE_LED_H_
#define HARDWARE_LED_H_
void LED_ON(void);

void LED_OFF(void);

void LED_Turn(void);

#endif /* HARDWARE_LED_H_ */
