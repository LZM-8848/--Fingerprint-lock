/*
 * Key.h
 *
 *  Created on: Nov 23, 2024
 *      Author: R
 */

#ifndef HARDWARE_KEYH_
#define HARDWARE_KEYH_


int Key_GetNum (void);



#endif /* HARDWARE_KEYH_ */
