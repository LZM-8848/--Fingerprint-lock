/*
 * Buzzer.c
 *
 *  Created on: Nov 23, 2024
 *      Author: R
 */

#include "main.h"
#include "stm32f1xx_hal.h"
void Buzzer_ON(void)
{
	HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_RESET);

}
void Buzzer_OFF(void)
{
	HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_SET);

}
void Buzzer_Turn(void)
{
	if(HAL_GPIO_ReadPin(Buzzer_GPIO_Port, Buzzer_Pin) == GPIO_PIN_SET)
	{
		HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_SET);
	}
}


