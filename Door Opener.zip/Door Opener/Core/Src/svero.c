#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "oled.h"
#include "LED.h"
#include "Buzzer.h"
#include "Flash.h"
#include "Key.h"


//设置舵机的角度
void Set_Angle(uint8_t angle)
{
	int duty = (angle+45)/0.9;//占空比<=>角度转换公式，仅适用于180°开环舵机
	if(duty<50){
		duty = 50;
	}else if(duty>250){
		duty = 250;
	}
	__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,duty);//50-250
}
