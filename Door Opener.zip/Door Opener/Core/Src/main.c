/* USER CODE BEGIN Header */
/*
 * 注意事项:若遇见编译后中文乱码现象请在WINDOWS中添加环境变量(详细见B站KeySking视频内容)
 *
 * 引脚使用说明:
 * 			Buzzer:PB12
 * 			Zhi Wen Sensor(指纹中断):PB1
 * 			LED:PB6
 *			UART1 : TX:PA9(接指纹传感器的RX)  RX:PA10(接指纹传感器的TX)
 *			TIM1_CH1(舵机角度控制): PA8
 *
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled.h"
#include "LED.h"
#include "Buzzer.h"
#include "Flash.h"
#include "Key.h"
#include "svero.h"
#include "command.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
const unsigned char auto_indetify[]= {0xEF,0x01,0xFF,0xFF,0xFF,0xFF,0x01,0x00,0x08,0x32,0x02,0xFF,0xFF,0x00,0x04,0x02,0x3F };// 1:N自动验证,不返回关键步骤,安全等级2
const unsigned char close_led[]= {0xEF, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x07, 0x3C, 0x04, 0x04, 0x00, 0x00, 0x00, 0x4C };//关闭呼吸灯
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/*################用户全局变量###############*/
uint8_t Open_flag = 0;//开门标志位，为1时控制舵机开门
uint8_t readBuffer[256];//UART接收缓冲区，因为使用了UART中断，所以即使一个包不满此缓冲区也会触发中断被单片机采集
uint8_t command[256];//指令包数组，单条包指令可达256字节
uint8_t commandLength = 0;//指令包长度
int8_t ret;//接收指纹验证的返回值，用于判断是否匹配成功
/*################用户全局变量###############*/
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*################重要中断回调函数###############*/
/*函数名称:GPIO中断回调函数
 * 	功能:GPIO外部中断控制按键
 * 	返回值：NONE
 * 	注意：不能用的时候注意SYSTick的中断优先级要高于这个函数
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

	/*Function: Key call back*/
	HAL_Delay(10);
	//------------------------内部调试----------------------------
	if(HAL_GPIO_ReadPin(Key_GPIO_Port, Key_Pin) == GPIO_PIN_SET)
		 	 {
				if(Open_flag == 0){
					Open_flag = 1;
				}else{Open_flag = 0;}

		 	 }
	//----------------------------------------------------------

	//------------------------指纹传感器中断返回---------------------
	else if(HAL_GPIO_ReadPin(Zhi_Wen_Sensor_GPIO_Port, Zhi_Wen_Sensor_Pin) == GPIO_PIN_SET)
		 	 {//在这里写检测到手指后的操作
	    		HAL_UART_Transmit(&huart1, auto_indetify, sizeof(auto_indetify), HAL_MAX_DELAY);//发送检测指令
		 	 }
	//----------------------------------------------------------
}

//---------------------------UART中断回调函数------------------------
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){
	if(huart == &huart1){
		Command_Write(readBuffer, Size);//将UART缓冲区里的数据拷贝到环形缓冲区
		HAL_UARTEx_ReceiveToIdle_IT(&huart1, readBuffer, sizeof(readBuffer));//再次启用串口中断
		Open_flag = 5;
	}
}
//----------------------------------------------------------------
/*################重要中断回调函数###############*/
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  /*################在这里写模块初始化函数！！！###############*/
  HAL_Delay(20); // 延迟等待
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);//开启PWM
  HAL_UARTEx_ReceiveToIdle_IT(&huart1, readBuffer, sizeof(readBuffer));//使能串口中断

  /*################在这里写模块初始化函数！！！###############*/
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  //--启动成功声光指示--
  Buzzer_ON();
  LED_ON();
  HAL_Delay(200);
  Buzzer_OFF();
  LED_OFF();
  //----------------

  HAL_UART_Transmit(&huart1, close_led, sizeof(close_led), HAL_MAX_DELAY);//关闭默认蓝色LED(太高调了不好)

  while (1)
  {
	  	  	//------------舵机控制循环------------
			if(Open_flag == 1){
				Set_Angle(10);
				HAL_Delay(3000);//可以改成内部定时器中断，懒得改了
				Set_Angle(110);
				Open_flag = 0;
			}
			//---------------------------------

			//--------------UART数据处理循环----------------
			commandLength = Command_GetCommand_HiLink(command);//获取环形缓冲区中的指令
			if(commandLength != 0){
				ret = Command_Process_HiLink(command);//解析收到的数据包
				if(ret >= 0){//指纹比对成功!
					  Buzzer_ON();
					  LED_ON();
					  HAL_Delay(500);
					  Buzzer_OFF();
					  LED_OFF();
					  Open_flag = 1;
				}
				else if(ret == -2){//指纹比对失败!
					for(int i = 0;i <3;i++){
					  Buzzer_ON();
					  LED_ON();
					  HAL_Delay(100);
					  Buzzer_OFF();
					  LED_OFF();
					  HAL_Delay(100);
					  Open_flag = 0;
					}
				}
				else{Open_flag = 0;}
	    		HAL_UART_Transmit(&huart1, close_led, sizeof(close_led), HAL_MAX_DELAY);
	    		memset(command, 0, sizeof(command)); // 将整个数组设置为 0
			}
			//--------------------------------------------
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	//##############别往下看了，下面全是初始化，就这么多################

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
