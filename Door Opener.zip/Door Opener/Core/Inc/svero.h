/*
 * svero.h
 *
 *  Created on: Jun 22, 2025
 *      Author: R
 */

#ifndef INC_SVERO_H_
#define INC_SVERO_H_

void Set_Angle(uint8_t angle);


#endif /* INC_SVERO_H_ */
